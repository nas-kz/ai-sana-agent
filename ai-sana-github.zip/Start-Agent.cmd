@echo off
cd /d "%~dp0"
"C:\Users\NAS_kz\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --env-file=.env.local local-server.mjs
pause
